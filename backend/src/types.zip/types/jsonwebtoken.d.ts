declare module 'jsonwebtoken';

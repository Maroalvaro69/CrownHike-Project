// src/routes/peaks.ts
import express from 'express';
import { pool } from '../db/pool.js';

const router = express.Router();

/**
 * GET /peaks — lista szczytów (publiczne)
 *
 * Query params (opcjonalne):
 *  - page  (domyślnie 1, >=1)
 *  - limit (domyślnie 50, maks 200)
 *  - difficulty        ∈ {EASY, MODERATE, HARD, EXPERT}
 *  - main_trail_color  ∈ {RED, BLUE, GREEN, YELLOW, BLACK, MIXED}
 *  - mountain_range    np. 'Tatry Wysokie', 'Tatry Zachodnie', ...
 *  - search            fragment nazwy szczytu (LIKE %search%)
 *  - sort              ∈ {name, height, difficulty}  (domyślnie: height)
 *  - dir               ∈ {asc, desc}                 (domyślnie: desc dla height, w innym wypadku asc)
 *
 * Zwracamy:
 *  - id
 *  - name
 *  - region        (alias z mountain_range)
 *  - elevation_m   (alias z height_m)
 *  - difficulty
 *  - main_trail_color
 *  - lat
 *  - lng
 *  - description
 */
router.get('/', async (req, res) => {
  try {
    const q = req.query as Record<string, string | undefined>;

    // paginacja
    const pageNum = Number(q.page ?? 1);
    const limitNum = Number(q.limit ?? 50);

    const page = Number.isFinite(pageNum) && pageNum > 0 ? pageNum : 1;
    let limit = Number.isFinite(limitNum) && limitNum > 0 ? limitNum : 50;
    if (limit > 200) limit = 200; // bez przesady z ilością ;)

    const offset = (page - 1) * limit;

    // filtry
    const difficulty = q.difficulty?.toString();
    const trailColor = q.main_trail_color?.toString();
    const range = q.mountain_range?.toString();
    const search = q.search?.toString();

    // sortowanie
    const sortRaw = q.sort?.toString() ?? 'height';
    const dirRaw = (q.dir?.toString() ?? '').toLowerCase();

    let sortColumn: string;
    switch (sortRaw) {
      case 'name':
        sortColumn = 'name';
        break;
      case 'difficulty':
        sortColumn = 'difficulty';
        break;
      case 'height':
      default:
        sortColumn = 'height_m';
        break;
    }

    // domyślny kierunek:
    // - jeśli sortujemy po wysokości -> DESC (jak było)
    // - w pozostałych przypadkach -> ASC
    let sortDir: 'ASC' | 'DESC';
    if (dirRaw === 'asc' || dirRaw === 'desc') {
      sortDir = dirRaw === 'desc' ? 'DESC' : 'ASC';
    } else {
      sortDir = sortColumn === 'height_m' ? 'DESC' : 'ASC';
    }

    const where: string[] = [];
    const params: any[] = [];

    if (difficulty) {
      where.push('difficulty = ?');
      params.push(difficulty);
    }

    if (trailColor) {
      where.push('main_trail_color = ?');
      params.push(trailColor);
    }

    if (range) {
      where.push('mountain_range = ?');
      params.push(range);
    }

    if (search) {
      where.push('name LIKE ?');
      params.push(`%${search}%`);
    }

    let sql =
      `SELECT
          id,
          name,
          mountain_range AS region,
          height_m       AS elevation_m,
          difficulty,
          main_trail_color,
          lat,
          lng,
          description
       FROM peaks`;

    if (where.length > 0) {
      sql += ' WHERE ' + where.join(' AND ');
    }

    sql += ` ORDER BY ${sortColumn} ${sortDir}`;
    sql += ` LIMIT ? OFFSET ?`;

    params.push(limit, offset);

    const [rows] = await pool.query(sql, params);
    const list = rows as any[];

    res.json({
      ok: true,
      page,
      limit,
      count: list.length,
      data: list,
    });
  } catch (err: any) {
    console.error(err);
    res
      .status(500)
      .json({ ok: false, error: err?.message ?? 'Internal server error' });
  }
});

/**
 * GET /peaks/:id — szczegóły pojedynczego szczytu (publiczne)
 *
 * Zwracamy:
 *  - id
 *  - name
 *  - region
 *  - elevation_m
 *  - difficulty
 *  - main_trail_color
 *  - lat
 *  - lng
 *  - description
 */
router.get('/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ ok: false, error: 'Invalid id' });
    }

    const [rows] = await pool.query(
      `SELECT
          id,
          name,
          mountain_range AS region,
          height_m       AS elevation_m,
          difficulty,
          main_trail_color,
          lat,
          lng,
          description
       FROM peaks
       WHERE id = ?`,
      [id]
    );

    const list = rows as any[];
    if (list.length === 0) {
      return res.status(404).json({ ok: false, error: 'Peak not found' });
    }

    res.json({ ok: true, data: list[0] });
  } catch (err: any) {
    console.error(err);
    res
      .status(500)
      .json({ ok: false, error: err?.message ?? 'Internal server error' });
  }
});

export default router;
